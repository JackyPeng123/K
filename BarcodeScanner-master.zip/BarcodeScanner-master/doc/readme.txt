参考文档
http://my.oschina.net/madmatrix/blog/189031